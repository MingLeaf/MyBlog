package com.example.exchange;

import com.example.exchange.proto.Order;
import com.example.exchange.proto.OrderStatus;
import com.example.exchange.proto.Product;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ExchangeApp {
    private static Order createOrder() {
        Product python = Product.newBuilder()
                .setId(101)
                .setName("Python Guide")
                .setPriceCents(2999)
                .build();

        Product java = Product.newBuilder()
                .setId(102)
                .setName("Java Guide")
                .setPriceCents(5999)
                .build();

        return Order.newBuilder()
                .setId(10001)
                .setStatus(OrderStatus.ORDER_STATUS_PAID)
                .addProducts(python)
                .addProducts(java)
                .putQuantities("101", 2)
                .putQuantities("102", 1)
                .setCouponCode("SAVE20")
                .setEmail("student@example.com")
                .build();
    }

    private static void inspectOrder(Order order) {
        System.out.println("id: " + order.getId());
        System.out.println("status: " + order.getStatus());
        for (Product product : order.getProductsList()) {
            System.out.println("product: " + product.getId() + ", " +
                    product.getName() + ", cents=" + product.getPriceCents());
        }
        System.out.println("quantities: " + order.getQuantitiesMap());
        System.out.println("coupon: " + order.getCouponCode() +
                ", present: " + order.hasCouponCode());
        System.out.println("contact: " + order.getContactCase() +
                ", " + order.getEmail());

        if (order.getId() != 10001 ||
                order.getProductsCount() != 2 ||
                order.getQuantitiesOrDefault("101", 0) != 2 ||
                !order.hasCouponCode() ||
                order.getContactCase() != Order.ContactCase.EMAIL) {
            throw new IllegalStateException("Unexpected message content");
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2 || (!args[0].equals("send") && !args[0].equals("read"))) {
            throw new IllegalArgumentException("Usage: send|read FILE");
        }
        Path path = Path.of(args[1]);
        if (args[0].equals("send")) {
            Order order = createOrder();
            if (path.getParent() != null) Files.createDirectories(path.getParent());
            Files.write(path, order.toByteArray());
            System.out.println("Java sent " + path);
            inspectOrder(order);
        } else {
            Order order = Order.parseFrom(Files.readAllBytes(path));
            System.out.println("Java received " + path);
            inspectOrder(order);
        }
    }
}
