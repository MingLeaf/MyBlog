from pathlib import Path
from order_pb2 import Order
base = Path(__file__).resolve().parents[1]
for filename in ("forwarded.bin", "dropped.bin"):
    order = Order.FromString((base / filename).read_bytes())
    print(filename, "coupon:", repr(order.coupon_code),
          "has coupon:", order.HasField("coupon_code"),
          "paid:", order.is_paid, "has paid:", order.HasField("is_paid"))
