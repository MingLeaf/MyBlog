from pathlib import Path
from order_pb2 import Order
order = Order(id=10001, amount_cents=8999, coupon_code="SAVE20", is_paid=False)
assert order.HasField("is_paid")
destination = Path(__file__).resolve().parents[1] / "order_v2.bin"
destination.write_bytes(order.SerializeToString())
print("Made", destination, "bytes:", destination.stat().st_size)
