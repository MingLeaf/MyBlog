from pathlib import Path
from order_pb2 import Order
base = Path(__file__).resolve().parents[1]
order = Order.FromString((base / "order_v2.bin").read_bytes())
print("Old reader sees", order.id, order.amount_cents)
(base / "forwarded.bin").write_bytes(order.SerializeToString())
order.DiscardUnknownFields()
(base / "dropped.bin").write_bytes(order.SerializeToString())
