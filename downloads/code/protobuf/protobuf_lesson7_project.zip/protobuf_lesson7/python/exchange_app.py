import sys
from pathlib import Path
from exchange_pb2 import Order, Product, ORDER_STATUS_PAID


def create_order():
    order = Order(id=10001, status=ORDER_STATUS_PAID, coupon_code="SAVE20")
    order.products.add(id=101, name="Python Guide", price_cents=2999)
    order.products.add(id=102, name="Java Guide", price_cents=5999)
    order.quantities["101"] = 2
    order.quantities["102"] = 1
    order.email = "student@example.com"
    return order


def inspect_order(order):
    print("id:", order.id)
    print("status:", order.status)
    print("products:", [(p.id, p.name, p.price_cents) for p in order.products])
    print("quantities:", dict(order.quantities))
    print("coupon:", order.coupon_code, "present:", order.HasField("coupon_code"))
    print("contact:", order.WhichOneof("contact"), order.email)
    assert order.id == 10001
    assert len(order.products) == 2
    assert order.quantities["101"] == 2
    assert order.HasField("coupon_code")
    assert order.WhichOneof("contact") == "email"


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in {"send", "read"}:
        raise SystemExit("Usage: python python/exchange_app.py send|read FILE")
    action, filename = sys.argv[1:]
    file = Path(filename)
    if action == "send":
        order = create_order()
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(order.SerializeToString())
        print("Python sent", file, "bytes:", file.stat().st_size)
        inspect_order(order)
    else:
        order = Order.FromString(file.read_bytes())
        print("Python received", file)
        inspect_order(order)


if __name__ == "__main__":
    main()
