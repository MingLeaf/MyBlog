# Protobuf Lesson 7 — Java/Python Interoperability

Prerequisites: Python 3.9+, Java 17+, Maven 3.8+, Internet for initial dependency downloads.

## 1. Install Python dependencies
```bash
python -m pip install -r requirements.txt
```

## 2. Generate Python code from the shared schema
```bash
python -m grpc_tools.protoc -I java/src/main/proto --python_out=python java/src/main/proto/exchange.proto
```

## 3. Generate Java code and compile
```bash
cd java
mvn clean compile
cd ..
```

## 4. Python -> Java
Run these commands from the root of this example directory:
```bash
python python/exchange_app.py send shared/python_to_java.bin
(cd java && mvn exec:java -Dexec.args="read ../shared/python_to_java.bin")
```

## 5. Java -> Python
```bash
(cd java && mvn exec:java -Dexec.args="send ../shared/java_to_python.bin")
python python/exchange_app.py read shared/java_to_python.bin
```

The parenthesized `cd java && ...` commands run Maven from the Java project folder (bash/zsh). On Windows, enter the `java` folder and run the equivalent Maven commands before returning to the project root.

## 6. Round trip / assertions
The `read` commands assert that common fields are as expected. There is no gRPC or network transport here: the `.bin` files are the interchange medium.

## Lesson 6 solution
The `compatibility/` directory contains V1 and V2 `.proto` schemas and Python scripts. Run:

```bash
python -m grpc_tools.protoc -I compatibility/v1 --python_out=compatibility/v1 compatibility/v1/order.proto
python -m grpc_tools.protoc -I compatibility/v2 --python_out=compatibility/v2 compatibility/v2/order.proto
python compatibility/v2/make.py
python compatibility/v1/relay.py
python compatibility/v2/check.py
```

The two versions run in separate processes, avoiding descriptor conflicts.
