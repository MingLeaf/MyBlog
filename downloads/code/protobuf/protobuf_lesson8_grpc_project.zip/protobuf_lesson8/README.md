# Lesson 8: Python gRPC server + Python client + Java client

## Prerequisites

- Python 3.10+ (recommended 3.11+)
- Java JDK 17+
- Maven 3.8+
- Internet connection on first installation/build
- Local port `127.0.0.1:50051` must be free

This project uses **plaintext gRPC on loopback only**, for learning. Never expose this to the public network as-is. Add TLS, authentication and authorization for production.

## 1. Generate Python code (project root)

```bash
python -m pip install -r requirements.txt
python -m grpc_tools.protoc -I proto --python_out=python --grpc_python_out=python proto/student_service.proto
```

These files are generated:
- `python/student_service_pb2.py`
- `python/student_service_pb2_grpc.py`

## 2. Check Python functionality with an automated smoke test

```bash
python python/smoke_test.py
```

Expected:
`PASS: Python gRPC unary, server-streaming and error handling`

Do not run the smoke test at the same time as the main server (same port).

## 3. Run Python server (terminal A, from project root)

```bash
python python/server.py
```

This terminal stays open.

## 4. Python client (terminal B, from project root)

```bash
python python/client.py
```

CreateStudent(1001), GetStudent(1001), UpdateScore(1001, Computer, 100),
ListStudents and NOT_FOUND handling will be exercised.

## 5. Java client (terminal C)

From the project root:

```bash
cd java
mvn clean compile
mvn exec:java
```

Java will create Student 2002, query, update, stream-list and test NOT_FOUND.

The Java Maven build automatically runs both protobuf and grpc-java code generation.

## What gets generated?

Java source code under `java/target/generated-sources/protobuf/java/`
and service stubs under `java/target/generated-sources/protobuf/grpc-java/`.

## Troubleshooting

- `ModuleNotFoundError` for student_service_pb2: run the Python generation command.
- `UNAVAILABLE`: start server first; check port.
- `ALREADY_EXISTS`: the clients use fixed demo IDs. Both clients tolerate repeated CreateStudent calls; restart the server for a clean in-memory DB.
- `DEADLINE_EXCEEDED`: server slow/unreachable; check server and network.
- `mvn`/`java` unavailable: install JDK17 and Maven, check PATH.
- Java plugin protoc download: needs compatible platform binary and connectivity to Maven Central.

## Lesson 7 standalone solution

`lesson7_answer/` contains a matching student model, Python binary producer and Java Builder modification snippet with instructions; the same `Student` message in this project's proto is deliberately reused to ease comparison.
