"""Run from project root after generating Python protobuf files:
python python/smoke_test.py
No separately running server required.
"""
import grpc
import student_service_pb2 as pb
import student_service_pb2_grpc as rpc
from server import make_server

def main():
    server = make_server()
    server.start()
    try:
        with grpc.insecure_channel("127.0.0.1:50051") as channel:
            stub = rpc.StudentServiceStub(channel)
            student = pb.Student(id=1001, name="Alice", age=18, grade=pb.GRADE_SECOND)
            student.scores.add(subject="Math", points=95)
            created = stub.CreateStudent(pb.CreateStudentRequest(student=student), timeout=5)
            assert created.HasField("age") and created.age == 18
            fetched = stub.GetStudent(pb.GetStudentRequest(id=1001), timeout=5)
            assert fetched.name == "Alice"
            result = stub.UpdateScore(pb.UpdateScoreRequest(
                student_id=1001, subject="Math", points=100), timeout=5)
            assert result.scores[0].points == 100
            assert len(list(stub.ListStudents(pb.ListStudentsRequest(), timeout=5))) == 1
            try:
                stub.GetStudent(pb.GetStudentRequest(id=999), timeout=5)
                raise AssertionError("NOT_FOUND expected")
            except grpc.RpcError as e:
                assert e.code() == grpc.StatusCode.NOT_FOUND
            print("PASS: Python gRPC unary, server-streaming and error handling")
    finally:
        server.stop(grace=1).wait()

if __name__ == "__main__":
    main()
