import grpc
import student_service_pb2 as pb
import student_service_pb2_grpc as rpc

TARGET = "127.0.0.1:50051"

def main():
    with grpc.insecure_channel(TARGET) as channel:
        stub = rpc.StudentServiceStub(channel)
        student = pb.Student(
            id=1001, name="Alice", age=18,
            grade=pb.GRADE_SECOND,
            email="alice@example.com",
        )
        student.scores.add(subject="Math", points=95)
        student.scores.add(subject="English", points=88)
        student.scores.add(subject="Computer", points=99)

        try:
            created = stub.CreateStudent(
                pb.CreateStudentRequest(student=student), timeout=5
            )
        except grpc.RpcError as e:
            if e.code() != grpc.StatusCode.ALREADY_EXISTS:
                raise
            print("Student already exists; querying current record")
            created = stub.GetStudent(pb.GetStudentRequest(id=1001), timeout=5)
        print("Created / loaded:", created.name, created.id)

        fetched = stub.GetStudent(pb.GetStudentRequest(id=1001), timeout=5)
        print("GetStudent:", fetched.name, "age present:", fetched.HasField("age"))
        print("Scores:", [(s.subject, s.points) for s in fetched.scores])
        print("Average:", sum(s.points for s in fetched.scores) / len(fetched.scores))
        print("Contact:", fetched.WhichOneof("contact"))

        updated = stub.UpdateScore(
            pb.UpdateScoreRequest(student_id=1001, subject="Computer", points=100),
            timeout=5,
        )
        print("Updated Computer score:", [
            s.points for s in updated.scores if s.subject == "Computer"
        ])

        print("ListStudents (server streaming):")
        for item in stub.ListStudents(pb.ListStudentsRequest(), timeout=5):
            print(" ", item.id, item.name)

        try:
            stub.GetStudent(pb.GetStudentRequest(id=-999), timeout=5)
        except grpc.RpcError as e:
            print("Expected missing student:", e.code().name)


if __name__ == "__main__":
    main()
