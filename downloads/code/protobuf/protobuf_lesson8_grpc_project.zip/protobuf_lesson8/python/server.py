from concurrent import futures
import threading

import grpc
import student_service_pb2 as pb
import student_service_pb2_grpc as rpc

HOST = "127.0.0.1:50051"

class StudentService(rpc.StudentServiceServicer):
    def __init__(self):
        self.students = {}
        self.lock = threading.RLock()

    def CreateStudent(self, request, context):
        student = request.student
        if student.id <= 0 or not student.name.strip():
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "id must be positive and name nonblank")
        for score in student.scores:
            if not score.subject.strip() or not (0 <= score.points <= 100):
                context.abort(grpc.StatusCode.INVALID_ARGUMENT, "invalid subject or points")
        with self.lock:
            if student.id in self.students:
                context.abort(grpc.StatusCode.ALREADY_EXISTS, "student already exists")
            saved = pb.Student()
            saved.CopyFrom(student)
            self.students[student.id] = saved
            output = pb.Student()
            output.CopyFrom(saved)
            return output

    def GetStudent(self, request, context):
        with self.lock:
            student = self.students.get(request.id)
            if student is None:
                context.abort(grpc.StatusCode.NOT_FOUND, "student not found")
            output = pb.Student()
            output.CopyFrom(student)
            return output

    def ListStudents(self, request, context):
        with self.lock:
            snapshots = []
            for student in sorted(self.students.values(), key=lambda s: s.id):
                copied = pb.Student()
                copied.CopyFrom(student)
                snapshots.append(copied)
        for student in snapshots:
            yield student

    def UpdateScore(self, request, context):
        if not request.subject.strip() or not (0 <= request.points <= 100):
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "invalid subject or points")
        with self.lock:
            student = self.students.get(request.student_id)
            if student is None:
                context.abort(grpc.StatusCode.NOT_FOUND, "student not found")
            for score in student.scores:
                if score.subject == request.subject:
                    score.points = request.points
                    output = pb.Student()
                    output.CopyFrom(student)
                    return output
            context.abort(grpc.StatusCode.NOT_FOUND, "subject not found")


def make_server():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
    rpc.add_StudentServiceServicer_to_server(StudentService(), server)
    port = server.add_insecure_port(HOST)
    if port == 0:
        raise RuntimeError("could not bind " + HOST)
    return server


def main():
    server = make_server()
    server.start()
    print("Python gRPC server listening at", HOST, flush=True)
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        server.stop(grace=2).wait()


if __name__ == "__main__":
    main()
