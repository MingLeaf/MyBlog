// Reference example using generated classes from proto/student_service.proto.
// Put into a Java source directory and execute with the configured generated classes.
import com.example.school.proto.Student;
import java.nio.file.Files;
import java.nio.file.Path;

public class StudentRoundTrip {
    public static void main(String[] args) throws Exception {
        Student student = Student.parseFrom(
                Files.readAllBytes(Path.of("student.bin")));
        double average = student.getScoresList().stream()
                .mapToInt(score -> score.getPoints()).average()
                .orElseThrow();
        System.out.println(student.getName() + " average=" + average);

        Student.Builder builder = student.toBuilder();
        for (int i=0; i<builder.getScoresCount(); i++) {
            if (builder.getScores(i).getSubject().equals("Computer")) {
                builder.getScoresBuilder(i).setPoints(100);
            }
        }
        Files.write(Path.of("student_updated.bin"), builder.build().toByteArray());
    }
}
