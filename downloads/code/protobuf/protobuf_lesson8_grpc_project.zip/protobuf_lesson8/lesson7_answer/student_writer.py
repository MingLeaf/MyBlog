# First run Python code-generation command shown in root README.
# Then from project root run:
# PYTHONPATH=python python lesson7_answer/student_writer.py
from pathlib import Path
from student_service_pb2 import Student, GRADE_SECOND

student = Student(id=1001, name="Alice", age=18,
                  grade=GRADE_SECOND, email="alice@example.com")
student.scores.add(subject="Math", points=95)
student.scores.add(subject="English", points=88)
student.scores.add(subject="Computer", points=99)

destination = Path("lesson7_answer/student.bin")
destination.write_bytes(student.SerializeToString())
assert student.HasField("age")
print("Wrote", destination, "with", len(student.scores), "scores")
