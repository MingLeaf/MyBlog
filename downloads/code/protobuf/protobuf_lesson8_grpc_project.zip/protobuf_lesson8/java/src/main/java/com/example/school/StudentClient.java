package com.example.school;

import com.example.school.proto.CreateStudentRequest;
import com.example.school.proto.GetStudentRequest;
import com.example.school.proto.Grade;
import com.example.school.proto.ListStudentsRequest;
import com.example.school.proto.Score;
import com.example.school.proto.Student;
import com.example.school.proto.StudentServiceGrpc;
import com.example.school.proto.UpdateScoreRequest;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;

import java.util.concurrent.TimeUnit;

public final class StudentClient {
    public static void main(String[] args) throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder
                .forAddress("127.0.0.1", 50051)
                .usePlaintext() // local tutorial only; production should use TLS
                .build();

        try {
            StudentServiceGrpc.StudentServiceBlockingStub stub =
                    StudentServiceGrpc.newBlockingStub(channel);

            Student student = Student.newBuilder()
                    .setId(2002)
                    .setName("Bob")
                    .setAge(19)
                    .setGrade(Grade.GRADE_SECOND)
                    .addScores(Score.newBuilder().setSubject("Math").setPoints(93).build())
                    .addScores(Score.newBuilder().setSubject("English").setPoints(91).build())
                    .setEmail("bob@example.com")
                    .build();

            try {
                Student created = stub.withDeadlineAfter(5, TimeUnit.SECONDS).createStudent(CreateStudentRequest.newBuilder()
                        .setStudent(student).build());
                System.out.println("Created: " + created.getId() + " " + created.getName());
            } catch (StatusRuntimeException e) {
                if (e.getStatus().getCode() != Status.Code.ALREADY_EXISTS) throw e;
                System.out.println("Student 2002 already exists");
            }

            Student fetched = stub.withDeadlineAfter(5, TimeUnit.SECONDS).getStudent(
                    GetStudentRequest.newBuilder().setId(2002).build());
            System.out.println("Fetched: " + fetched.getName()
                    + " age present=" + fetched.hasAge()
                    + " contact=" + fetched.getContactCase());
            for (Score score : fetched.getScoresList()) {
                System.out.println("  " + score.getSubject() + ": " + score.getPoints());
            }

            Student updated = stub.withDeadlineAfter(5, TimeUnit.SECONDS).updateScore(UpdateScoreRequest.newBuilder()
                    .setStudentId(2002)
                    .setSubject("Math")
                    .setPoints(100)
                    .build());
            System.out.println("Updated score: " + updated.getScores(0).getPoints());

            System.out.println("ListStudents (server streaming):");
            var iterator = stub.withDeadlineAfter(5, TimeUnit.SECONDS).listStudents(ListStudentsRequest.getDefaultInstance());
            while (iterator.hasNext()) {
                Student s = iterator.next();
                System.out.println("  " + s.getId() + " " + s.getName());
            }

            try {
                stub.withDeadlineAfter(5, TimeUnit.SECONDS).getStudent(GetStudentRequest.newBuilder().setId(-999).build());
                throw new IllegalStateException("expected NOT_FOUND");
            } catch (StatusRuntimeException e) {
                if (e.getStatus().getCode() != Status.Code.NOT_FOUND) throw e;
                System.out.println("Expected error: " + e.getStatus().getCode());
            }
        } finally {
            channel.shutdown();
            if (!channel.awaitTermination(5, TimeUnit.SECONDS)) {
                channel.shutdownNow();
            }
        }
    }
}
