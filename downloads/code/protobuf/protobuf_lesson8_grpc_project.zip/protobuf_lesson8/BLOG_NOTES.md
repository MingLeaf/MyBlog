# 博客配套版说明

Java StudentClient 在每次 RPC 前设置 Deadline，避免复用初始化 Stub 时创建的截止时间。其余原始文件保持不变。
